import { createSlice } from "@reduxjs/toolkit"

const storeforPrivacy = createSlice({
    name:"privacy",
    initialState:false,
    reducers:{
        changePrivacy:(state,action)=>{
               return     !state
        }
    }
})
export const privacyActions = storeforPrivacy.actions
export default storeforPrivacy