import {configureStore, createSlice} from '@reduxjs/toolkit'
import storeforPrivacy from './privacy';

const storeForCounter = createSlice(
    {
        name:"counter",
        initialState:{
            counterVal:0
        },
        reducers:{
            increment:(state)=>{
                state.counterVal++;
            },
            decrement:(state)=>{
                state.counterVal--;
                
            },
            inputBtn:(state,action)=>{
                state.counterVal = state.counterVal + +action.payload.inputValue
            },
            btnAdd:(state,action)=>{
               state.counterVal = state.counterVal+ action.payload.num
            },
        }
    }
)

const counterReduxStore = configureStore(
    {
        reducer:{
            counter:storeForCounter.reducer,
            privacy:storeforPrivacy.reducer
        }
    }
)
export const storeActions = storeForCounter.actions
export default counterReduxStore;