import {createStore} from 'redux'
const INT_VAL = {
    counter:55,
    privacy:false
}
const counterReducer = (state= INT_VAL,action)=>{
    let newState = state
    if(action.type==="INCREMENT"){
        // newState = {counter:state.counter + 1,privacy:state.privacy}
        newState = {...state,counter:state.counter + 1}
    }else if(action.type==='DECREMENT'){
        newState = {...state,counter:state.counter - 1}
    }else if(action.type==="BTN_INC"){
        newState = {...state,counter:state.counter + action.addNum}

    }else if(action.type==="INPUTBTN"){
        newState = {...state,counter:state.counter + +(action.inputValue)}

    }else if(action.type==="PRIVACY"){
        newState = {...state,privacy:!state.privacy}

    }
    return newState;
}

const counterStore = createStore(counterReducer)
export default counterStore; 