import React, { useRef } from "react";
import { useDispatch } from "react-redux";
import { storeActions } from "../Store/ReduxToolKIt";
import { privacyActions } from "../Store/privacy";

const Operation = () => {
  const getValue = useRef()
  const dispatch = useDispatch();
  const handleIncrement = () => {
    dispatch(storeActions.increment())
  };
  const handleDecrement = () => {
    dispatch(storeActions.decrement());
  };
  const handleAddBtn = ()=>{
    dispatch(storeActions.inputBtn({
      inputValue:getValue.current.value
    }))
    getValue.current.value = ""
  }
  const handlePrivacy = ()=>{
    dispatch(privacyActions.changePrivacy())
  }
  return (
    <>
      <div className="d-grid gap-2 d-sm-flex justify-content-sm-center">
        <button
          type="button"
          onClick={handleIncrement}
          className="btn btn-success btn-lg px-4 gap-3"
        >
          + INC
        </button>
        <button
          type="button"
          onClick={handleDecrement}
          className="btn btn-danger btn-lg px-4"
        >
          - DEC
        </button>
        <button
          type="button"
          onClick={handlePrivacy}
          className="btn btn-warning btn-lg px-2"
        >
          Privacy
        </button>
      </div>
      <div
        class="btn-group my-3"
        role="group"
        aria-label="Basic mixed styles example"
      >
        <button
          type="button"
          onClick={() => dispatch(storeActions.btnAdd({num:10}))}
          class="btn btn-danger btn-lg"
        >
          +10
        </button>
        <button
        onClick={() => dispatch(storeActions.btnAdd({num:20}))}
          type="button"
          class="btn btn-warning btn-lg"
        >
          +20
        </button>
        <button
        onClick={() => dispatch(storeActions.btnAdd({num:50}))}
          type="button"
          class="btn btn-success btn-lg"
        >
          +50
        </button>
        <button
        onClick={() => dispatch(storeActions.btnAdd({num:100}))}
          type="button"
          class="btn btn-dark btn-lg"
        >
          +100
        </button>
      </div>
      <div className="input-group">
        <input type="text" className="form-control" ref={getValue} />
        <button className="btn btn-success"
          onClick={handleAddBtn}
        >Add</button>
      </div>
    </>
  );
};

export default Operation;
