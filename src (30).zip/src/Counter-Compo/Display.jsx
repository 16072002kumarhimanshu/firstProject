import React from 'react'
import { useSelector } from 'react-redux'

const Display = () => {
   const {counterVal} = useSelector(
        (state)=> state.counter
    )
  return (
    <>
    <p className="lead mb-4 text-primary fs-3">Current Value of Counter:{counterVal} </p>
    </>
  )
}

export default Display