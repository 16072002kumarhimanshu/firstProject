import React from 'react'

const Privacy = () => {
  return (
    <>
    <p className="lead mb-4 text-primary fs-3">Current Value is private </p>
    
    </>
  )
}

export default Privacy