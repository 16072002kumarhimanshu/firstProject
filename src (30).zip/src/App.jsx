import React from "react";
import Header from "./Counter-Compo/Header";
import Display from "./Counter-Compo/Display";
import { Provider, useSelector } from 'react-redux' 
import counterStore from "./Store/Store";
import Operation from "./Counter-Compo/Operation";
import Privacy from "./Counter-Compo/Privacy";
const App = () => {
 const privacyVal =  useSelector(
    (state)=> state.privacy
  )
  return (
    <>
  
      <div className="px-4 py-5 my-5 text-center border border-5 shadow w-50 mx-auto">
        <Header />
        <div className="col-lg-6 mx-auto">
          {privacyVal ? <Privacy/>:<Display />}
          <Operation/>
        </div>
      </div>
    </>
  );
};

export default App;
