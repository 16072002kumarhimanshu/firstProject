import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import 'bootstrap/dist/css/bootstrap.min.css'
import { Provider } from 'react-redux'
// import counterStore from './Store/Store.js'
import counterReduxStore from './Store/ReduxToolKIt.js'
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Provider store={counterReduxStore}>

    <App />
    </Provider>
  </React.StrictMode>,
)
